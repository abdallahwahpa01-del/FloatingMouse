package com.example.floatingmouse;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.accessibility.AccessibilityEvent;

public class MouseAccessibilityService extends AccessibilityService {

    private FloatingView floatingView;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE;
        setServiceInfo(info);

        floatingView = new FloatingView(this);
        floatingView.show();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // يمكن هنا معالجة الأحداث مستقبلاً
    }

    @Override
    public void onInterrupt() {
        if (floatingView != null) {
            floatingView.hide();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null) {
            floatingView.hide();
        }
    }
}
