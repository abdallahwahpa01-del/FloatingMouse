package com.example.floatingmouse;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.widget.ImageView;

public class FloatingService extends Service {

    private WindowManager windowManager;
    private ImageView floatingCursor;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showFloatingCursor();
    }

    private void showFloatingCursor() {
        floatingCursor = new ImageView(this);
        floatingCursor.setImageResource(R.drawable.ic_mouse_pointer);

        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            60,
            60,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 100;

        windowManager.addView(floatingCursor, params);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingCursor != null) {
            windowManager.removeView(floatingCursor);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
